#import <Foundation/Foundation.h>
#import "Menu.h"
#import "HelperFiles/utils.h"

#define UIColorFromHex(hexColor) [UIColor colorWithRed:((float)((hexColor & 0xFF0000) >> 16))/255.0 green:((float)((hexColor & 0xFF00) >> 8))/255.0 blue:((float)(hexColor & 0xFF))/255.0 alpha:1.0]


@interface Menu ()

@property (assign, nonatomic) CGPoint lastMenuLocation;
@property (strong, nonatomic) UILabel *menuTitle;
@property (strong, nonatomic) UIView *header;
@property (strong, nonatomic) UIView 
*borderSect;
@property (strong, nonatomic) UIView 
*footer;
@property (strong, nonatomic) UILabel *footerText;



@end


@implementation Menu

NSUserDefaults *defaults;

UIScrollView *scrollView;
UIScrollView *scrollView2;
UIScrollView *scrollView3;
UIScrollView *scrollView4;
UIScrollView *scrollView5;
CGFloat menuWidth;
CGFloat scrollViewX;
NSString *credits;
UIColor *switchOnColor;
NSString *switchTitleFont;
UIColor *switchTitleColor;
UIColor *infoButtonColor;
NSString *menuIconBase64;
NSString *menuButtonBase64;
float scrollViewHeight = 0;
float scrollView2Height = 0;
float scrollView3Height = 0;
float scrollView4Height = 0;
float scrollView5Height = 0;
BOOL hasRestoredLastSession = false;
UIButton *menuButton;


const char *frameworkName = NULL;

UIButton *button  = [UIButton buttonWithType:UIButtonTypeCustom];
UIButton *button2  = [UIButton buttonWithType:UIButtonTypeCustom];
UIButton *button3 = [UIButton buttonWithType:UIButtonTypeCustom];
UIButton *button5 = [UIButton buttonWithType:UIButtonTypeCustom];
UIButton *button6 = [UIButton buttonWithType:UIButtonTypeCustom];
UIButton *button7 = [UIButton buttonWithType:UIButtonTypeCustom];
UIWindow *mainWindow;
UIWindow *window;
UILabel *watermark;
UIDevice *myDevice;
NSDateFormatter *ttime;
UIView *menuTopBorder;
UIView *menuBottomBorder;
UIView *menuLeftBorder;
UIView *menuRightBorder;
UIView *menuRightBorder1;
UIView *menuRightBorder2;

Menu *menu = [[Menu alloc]init];
Switches *switches = [[Switches alloc]init];

-(id)initWithTitle:(NSString *)title_ watermarkText:(NSString *)watermarkText_ watermarkTextColor:(UIColor *)watermarkTextColor_ watermarkVisible:(float)watermarkVisible_ titleColor:(UIColor *)titleColor_ titleFont:(NSString *)titleFont_ credits:(NSString *)credits_ 
initWithTitle:(NSString *)footerTitle_ titleColor:(UIColor *)footerTitleColor_ titleFont:(NSString *)footerTitleFont_ initWithTitle:(NSString *)footerTitle1_ titleColor:(UIColor *)footerTitleColor1_ titleFont:(NSString *)footerTitleFont1_
headerColor:(UIColor *)headerColor_ switchOffColor:(UIColor *)switchOffColor_ switchOnColor:(UIColor *)switchOnColor_ switchTitleFont:(NSString *)switchTitleFont_ switchTitleColor:(UIColor *)switchTitleColor_ infoButtonColor:(UIColor *)infoButtonColor_   maxVisibleSwitches:(int)maxVisibleSwitches_ menuWidth:(CGFloat )menuWidth_ menuIcon:(NSString *)menuIconBase64_ menuButton:(NSString *)menuButtonBase64_ {
    mainWindow = [UIApplication sharedApplication].keyWindow;
    defaults = [NSUserDefaults standardUserDefaults];

    menuWidth = menuWidth_;
    switchOnColor = switchOnColor_;
    credits = credits_;
    switchTitleFont = switchTitleFont_;
    switchTitleColor = switchTitleColor_;
    infoButtonColor = infoButtonColor_;
    menuButtonBase64 = menuButtonBase64_;

NSString *bat = @"%";

    myDevice = [UIDevice currentDevice];
       [myDevice setBatteryMonitoringEnabled:YES];
           double batLeft = (float)[myDevice batteryLevel] * 100;

   ttime = [[NSDateFormatter alloc] init];
      [ttime setDateFormat:@"HH:mm:ss"];         
watermark = [[UILabel alloc]initWithFrame:CGRectMake(5, 0, 153.5, 25)];
watermark.textColor = [UIColor whiteColor];
watermark.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.00];
watermark.layer.borderColor = [UIColor clearColor].CGColor;
watermark.layer.borderWidth = 2.0f;
watermark.layer.cornerRadius = 1.0;
watermark.text = [NSString stringWithFormat:@" By LegendWare | %.0f%@ | %@",batLeft,bat,[ttime stringFromDate:[NSDate date]]];
watermark.adjustsFontSizeToFitWidth = YES;
watermark.layer.opacity = 0;
watermark.font = [UIFont fontWithName:@"Avenir-Heavy" size:13.0f];
watermark.center = CGPointMake(CGRectGetMaxX(mainWindow.frame)-(watermark.frame.size.width/2)-[[switches getValueFromSwitch:@"Watermark X:"] floatValue], CGRectGetMinY(mainWindow.frame)+(watermark.frame.size.height/2)+[[switches getValueFromSwitch:@"Watermark Y:"] floatValue]);
[mainWindow addSubview:watermark];

[NSTimer scheduledTimerWithTimeInterval:0.001f target:self selector:@selector(watermark) userInfo:nil repeats:YES];

        [UIView animateWithDuration:0.25 animations:^ {
if([switches isSwitchOn:@"Watermark"]){
watermark.layer.opacity = 1;
}else{
watermark.layer.opacity = 0;
}
}];

    self = [super initWithFrame:CGRectMake(0,0,menuWidth_, maxVisibleSwitches_ * 50 + 50)];
    self.center = mainWindow.center;
    self.layer.opacity = 0.0f;

    self.header = [[UIView alloc]initWithFrame:CGRectMake(0, 0, menuWidth_, 50)];
    self.header.backgroundColor = switchOffColor_;
    CAShapeLayer *headerLayer = [CAShapeLayer layer];
    headerLayer.path = [UIBezierPath bezierPathWithRoundedRect: self.header.bounds byRoundingCorners: UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii: (CGSize){9.0, 0.0}].CGPath;
    self.header.layer.mask = headerLayer;
    [self addSubview:self.header];

    NSData* data = [[NSData alloc] initWithBase64EncodedString:menuIconBase64_ options:0];
    UIImage* menuIconImage = [UIImage imageWithData:data];

    UIButton *menuIcon = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    menuIcon.frame = CGRectMake(5, 1, 50, 50);
    menuIcon.backgroundColor = [UIColor clearColor];
    [menuIcon setBackgroundImage:menuIconImage forState:UIControlStateNormal];

    [menuIcon addTarget:self action:@selector(menuIconTapped) forControlEvents:UIControlEventTouchDown];
    [self.header addSubview:menuIcon];

        scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.header.bounds), menuWidth_, CGRectGetHeight(self.bounds) - CGRectGetHeight(self.header.bounds))];
    scrollView.backgroundColor = switchOffColor_;
    scrollView.alpha = 1.0f;
    [self addSubview:scrollView];

    scrollView2 = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.header.bounds), menuWidth_, CGRectGetHeight(self.bounds) - CGRectGetHeight(self.header.bounds))];
    scrollView2.backgroundColor = switchOffColor_;
    scrollView2.alpha = 0.0f;
    [self addSubview:scrollView2];

    scrollView3 = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.header.bounds), menuWidth_, CGRectGetHeight(self.bounds) - CGRectGetHeight(self.header.bounds))];
    scrollView3.backgroundColor = switchOffColor_;
    scrollView3.alpha = 0.0f;
    [self addSubview:scrollView3];

    scrollView4 = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.header.bounds), menuWidth_, CGRectGetHeight(self.bounds) - CGRectGetHeight(self.header.bounds))];
    scrollView4.backgroundColor = switchOffColor_;
    scrollView4.alpha = 0.0f;
_menuTitle = [[UILabel alloc]initWithFrame:CGRectMake(180, 70, 145, 20)];
_menuTitle.text = @"Crosshair Color:";
_menuTitle.textColor = [UIColor whiteColor];
_menuTitle.font = [UIFont fontWithName:@"AppleSDGothicNeo-Bold" size:16.0f];
_menuTitle.adjustsFontSizeToFitWidth = true;
_menuTitle.textAlignment = NSTextAlignmentCenter;
[scrollView4 addSubview:_menuTitle];
    [self addSubview:scrollView4];

scrollView5 = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.header.bounds), menuWidth_, CGRectGetHeight(self.bounds) - CGRectGetHeight(self.header.bounds))];
    scrollView5.backgroundColor = switchOffColor_;
    scrollView5.alpha = 0.0f;
    [self addSubview:scrollView5];

   menuRightBorder = [[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, 15, 1)];
   menuRightBorder.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:1.00];
   menuRightBorder.center = mainWindow.center;
    menuRightBorder.alpha = 0.0;
   [mainWindow addSubview: menuRightBorder];

   menuRightBorder1 = [[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, 1, 15)];
   menuRightBorder1.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:1.00];
   menuRightBorder1.center = mainWindow.center;
menuRightBorder1.alpha = 0.0;
   [mainWindow addSubview: menuRightBorder1];

[button addTarget:self 
 action:@selector(ButtonClicked:)
 forControlEvents:UIControlEventTouchUpInside];
[button setTitle:@">" forState:UIControlStateNormal];
[button.titleLabel setFont:[UIFont fontWithName:@"AppleSDGothicNeo-Bold" size:25.0f]];
button.frame = CGRectMake(315.0, 15.0, 75.0, 25.0);
button.layer.cornerRadius = 0.0;
button.layer.masksToBounds = true;
button.backgroundColor = [UIColor clearColor];
UITapGestureRecognizer *buttonTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ButtonClicked)];
[button addGestureRecognizer:buttonTap];
[_header addSubview:button];

[button2 addTarget:self 
 action:@selector(ButtonClicked2:)
 forControlEvents:UIControlEventTouchUpInside];
[button2 setTitle:@"Visual" forState:UIControlStateNormal];
[button2.titleLabel setFont:[UIFont fontWithName:@"AppleSDGothicNeo-Bold" size:16.0f]];
button2.frame = CGRectMake(232.5, 15.0, 75.0, 25.0);
button2.layer.cornerRadius = 0.0;
button2.layer.masksToBounds = true;
button2.backgroundColor = [UIColor clearColor];
UITapGestureRecognizer *buttonTap2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ButtonClicked2)];
[button2 addGestureRecognizer:buttonTap2];
[_header addSubview:button2];

[button3 addTarget:self 
 action:@selector(ButtonClicked3:)
 forControlEvents:UIControlEventTouchUpInside];
[button3 setTitle:@"<" forState:UIControlStateNormal];
[button3.titleLabel setFont:[UIFont fontWithName:@"AppleSDGothicNeo-Bold" size:25.0f]];
button3.frame = CGRectMake(150.0, 15.0, 75.0, 25.0);
button3.layer.cornerRadius = 0.0;
button3.layer.masksToBounds = true;
button3.hidden = YES;
button3.backgroundColor = [UIColor clearColor];
UITapGestureRecognizer *buttonTap3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ButtonClicked3)];
[button3 addGestureRecognizer:buttonTap3];
[_header addSubview:button3];

[button5 addTarget:self 
 action:@selector(ButtonClicked5:)
 forControlEvents:UIControlEventTouchUpInside];
[button5 setTitle:@"Black" forState:UIControlStateNormal];
[button5.titleLabel setFont:[UIFont fontWithName:@"AppleSDGothicNeo-Bold" size:16.0f]];
button5.frame = CGRectMake(350, 70, 50, 20);
button5.layer.cornerRadius = 0.0;
button5.layer.masksToBounds = true;
button5.backgroundColor = [UIColor clearColor];
UITapGestureRecognizer *buttonTap5 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ButtonClicked5)];
[button5 addGestureRecognizer:buttonTap5];
[scrollView4 addSubview:button5];

[button6 addTarget:self 
 action:@selector(ButtonClicked5:)
 forControlEvents:UIControlEventTouchUpInside];
[button6 setTitle:@"<" forState:UIControlStateNormal];
[button6.titleLabel setFont:[UIFont fontWithName:@"Avenir-Black" size:16.0f]];
button6.frame = CGRectMake(/*x*/390, /*y*/69, -105, 20);
button6.layer.cornerRadius = 0.0;
button6.layer.masksToBounds = true;
button6.backgroundColor = [UIColor clearColor];
UITapGestureRecognizer *buttonTap6 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ButtonClicked6)];
[button6 addGestureRecognizer:buttonTap6];
[scrollView4 addSubview:button6];

[button7 addTarget:self 
 action:@selector(ButtonClicked5:)
 forControlEvents:UIControlEventTouchUpInside];
[button7 setTitle:@">" forState:UIControlStateNormal];
[button7.titleLabel setFont:[UIFont fontWithName:@"Avenir-Black" size:16.0f]];
button7.frame = CGRectMake(/*x*/400, /*y*/69, 20, 20);
button7.hidden = YES;
button7.layer.cornerRadius = 0.0;
button7.layer.masksToBounds = true;
button7.backgroundColor = [UIColor clearColor];
UITapGestureRecognizer *buttonTap7 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ButtonClicked7)];
[button7 addGestureRecognizer:buttonTap7];
[scrollView4 addSubview:button7];

    scrollViewX = CGRectGetMinX(scrollView.self.bounds);

    self.menuTitle = [[UILabel alloc]initWithFrame:CGRectMake(-150, 5, menuWidth_ - 50, 45)];
    self.menuTitle.text = title_;
    self.menuTitle.textColor = titleColor_;
    self.menuTitle.font = [UIFont fontWithName:titleFont_ size:24.0f];
    self.menuTitle.adjustsFontSizeToFitWidth = true;
    self.menuTitle.textAlignment = NSTextAlignmentCenter;
    [self.header addSubview: self.menuTitle];

  self.footer = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.bounds), menuWidth_, 20)];
    self.footer.backgroundColor = switchOffColor_;
    CAShapeLayer *footerLayer = [CAShapeLayer layer];
    footerLayer.path = [UIBezierPath bezierPathWithRoundedRect:self.footer.bounds byRoundingCorners: UIRectCornerBottomLeft | UIRectCornerBottomRight cornerRadii: (CGSize){9.0, 9.0}].CGPath;
    self.footer.layer.mask = footerLayer;
    [self addSubview:self.footer];

self.footerText = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.bounds) - 1, menuWidth_, 20)];
    self.footerText.text = footerTitle_;
    self.footerText.textColor = footerTitleColor_;
    self.footerText.font = [UIFont fontWithName:footerTitleFont_ size:15.0f];
    self.footerText.adjustsFontSizeToFitWidth = true;
    self.footerText.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.footerText];

   self.footerText = [[UILabel alloc]initWithFrame:CGRectMake(-10, CGRectGetHeight(self.bounds) - 1, menuWidth_, 20)];
    self.footerText.text = footerTitle1_;
    self.footerText.textColor = footerTitleColor1_;
    self.footerText.font = [UIFont fontWithName:footerTitleFont1_ size:15.0f];
    self.footerText.adjustsFontSizeToFitWidth = true;
    self.footerText.textAlignment = NSTextAlignmentRight;
    [self addSubview:self.footerText];

    UIPanGestureRecognizer *dragMenuRecognizer  = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(menuDragged:)];
    [self.header addGestureRecognizer:dragMenuRecognizer];

    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideMenu:)];
    tapGestureRecognizer.numberOfTapsRequired = 2;
    [self.header addGestureRecognizer:tapGestureRecognizer];

    [mainWindow addSubview:self];
    [self showMenuButton];

    return self;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    self.lastMenuLocation = CGPointMake(CGRectGetMinX(self.frame), CGRectGetMinY(self.frame));
    [super touchesBegan:touches withEvent:event];
}

- (void)menuDragged:(UIPanGestureRecognizer *)pan {
    CGPoint newLocation = [pan translationInView:self.superview];
    self.frame = CGRectMake(self.lastMenuLocation.x + newLocation.x, self.lastMenuLocation.y + newLocation.y, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
}

- (void)hideMenu:(UITapGestureRecognizer *)tap {
    if(tap.state == UIGestureRecognizerStateEnded) {
        [UIView animateWithDuration:0.5 animations:^ {
            self.alpha = 0.0f;
            menuButton.alpha = 1.0f;
        }];
    }
}

-(void)showMenu:(UITapGestureRecognizer *)tapGestureRecognizer {
    if(tapGestureRecognizer.state == UIGestureRecognizerStateEnded) {
        menuButton.alpha = 0.0f;
        [UIView animateWithDuration:0.5 animations:^ {
            self.alpha = 1.0f;
        }];
    }

    if(!hasRestoredLastSession) {
        restoreLastSession();
        hasRestoredLastSession = true;
    }}

-(void) ButtonClicked2{

}

-(void) ButtonClicked5{

}


int da = 0;
int daa = 0;

-(void)ButtonClicked {

if(daa == 0){

[button2 setTitle:@"Visual" forState:UIControlStateNormal];

scrollView.alpha = 1.0f;
scrollView2.alpha = 0.0f;
scrollView3.alpha = 0.0f;
scrollView4.alpha = 0.0f;
scrollView5.alpha = 0.0f;

button.hidden = NO;
button3.hidden = YES;
da = 1;
daa = 1;

}else if(da == 1){

[button2 setTitle:@"Weapon" forState:UIControlStateNormal];

scrollView.alpha = 0.0f;
scrollView2.alpha = 1.0f;
scrollView3.alpha = 0.0f;
scrollView4.alpha = 0.0f;
scrollView5.alpha = 0.0f;

button3.hidden = NO;
button.hidden = NO;
da = 2;

}else if(da == 2){

[button2 setTitle:@"Global" forState:UIControlStateNormal];

scrollView.alpha = 0.0f;
scrollView2.alpha = 0.0f;
scrollView3.alpha = 1.0f;
scrollView4.alpha = 0.0f;
scrollView5.alpha = 0.0f;

button3.hidden = NO;
button.hidden = NO;
da = 3;

}else if(da == 3){

[button2 setTitle:@"Skins" forState:UIControlStateNormal];

scrollView.alpha = 0.0f;
scrollView2.alpha = 0.0f;
scrollView3.alpha = 0.0f;
scrollView4.alpha = 0.0f;
scrollView5.alpha = 1.0f;

button3.hidden = NO;
button.hidden = NO;
da = 4;

}else if(da == 4){

[button2 setTitle:@"Other" forState:UIControlStateNormal];

scrollView.alpha = 0.0f;
scrollView2.alpha = 0.0f;
scrollView3.alpha = 0.0f;
scrollView4.alpha = 1.0f;
scrollView5.alpha = 0.0f;

button3.hidden = NO;
button.hidden = YES;
da = 5;

}else if(daa == 1){

[button2 setTitle:@"Other" forState:UIControlStateNormal];

scrollView.alpha = 0.0f;
scrollView2.alpha = 0.0f;
scrollView3.alpha = 0.0f;
scrollView4.alpha = 1.0f;
scrollView5.alpha = 0.0f;

button3.hidden = NO;
button.hidden = YES;
da = 5;
daa = 2;
}
}

-(void)ButtonClicked3 {
if(daa == 2){
[button2 setTitle:@"Other" forState:UIControlStateNormal];

scrollView.alpha = 0.0f;
scrollView2.alpha = 0.0f;
scrollView3.alpha = 0.0f;
scrollView4.alpha = 1.0f;
scrollView5.alpha = 0.0f;

button.hidden = NO;
button3.hidden = NO;
da = 5;
daa = 1;

}else if(da == 5){

[button2 setTitle:@"Skins" forState:UIControlStateNormal];

scrollView.alpha = 0.0f;
scrollView2.alpha = 0.0f;
scrollView3.alpha = 0.0f;
scrollView4.alpha = 0.0f;
scrollView5.alpha = 1.0f;

button3.hidden = NO;
button.hidden = NO;
da = 4;

}else if(da == 4){

[button2 setTitle:@"Global" forState:UIControlStateNormal];

scrollView.alpha = 0.0f;
scrollView2.alpha = 0.0f;
scrollView3.alpha = 1.0f;
scrollView4.alpha = 0.0f;
scrollView5.alpha = 0.0f;

button3.hidden = NO;
button.hidden = NO;
da = 3;

}else if(da == 3){

[button2 setTitle:@"Weapon" forState:UIControlStateNormal];

scrollView.alpha = 0.0f;
scrollView2.alpha = 1.0f;
scrollView3.alpha = 0.0f;
scrollView4.alpha = 0.0f;
scrollView5.alpha = 0.0f;

button3.hidden = NO;
button.hidden = NO;
da = 2;

}else if(da == 2){

[button2 setTitle:@"Visual" forState:UIControlStateNormal];

scrollView.alpha = 1.0f;
scrollView2.alpha = 0.0f;
scrollView3.alpha = 0.0f;
scrollView4.alpha = 0.0f;
scrollView5.alpha = 0.0f;

button3.hidden = YES;
button.hidden = NO;
da = 1;
}else if(daa == 1){

[button2 setTitle:@"Visual" forState:UIControlStateNormal];

scrollView.alpha = 1.0f;
scrollView2.alpha = 0.0f;
scrollView3.alpha = 0.0f;
scrollView4.alpha = 0.0f;
scrollView5.alpha = 0.0f;

button3.hidden = YES;
button.hidden = NO;
da = 0;
daa = 0;
}
}

-(void)watermark{
NSString *bat = @"%";

    myDevice = [UIDevice currentDevice];
       [myDevice setBatteryMonitoringEnabled:YES];
           double batLeft = (float)[myDevice batteryLevel] * 100;

   ttime = [[NSDateFormatter alloc] init];
      [ttime setDateFormat:@"HH:mm:ss t"];


watermark.text = [NSString stringWithFormat:@" By LegendWare | %.0f%@ | %@",batLeft,bat,[ttime stringFromDate:[NSDate date]]];
watermark.center = CGPointMake(CGRectGetMaxX(mainWindow.frame)-(watermark.frame.size.width/2)-[[switches getValueFromSwitch:@"Watermark X:"] floatValue], CGRectGetMinY(mainWindow.frame)+(watermark.frame.size.height/2)+[[switches getValueFromSwitch:@"Watermark Y:"] floatValue]);

        [UIView animateWithDuration:0.25 animations:^ {
if([switches isSwitchOn:@"Crosshair"]){
menuRightBorder.alpha = 1.0;

menuRightBorder1.alpha = 1.0;

}
else{

menuRightBorder.alpha = 0.0;

menuRightBorder1.alpha = 0.0;
}
}];
}

int cross = 0;
int crosss = 0;

-(void)ButtonClicked6{

if(crosss == 0){

[button5 setTitle:@"Red" forState:UIControlStateNormal];

menuRightBorder1.backgroundColor = [UIColor redColor];                 
menuRightBorder.backgroundColor = [UIColor redColor];

button6.hidden = NO;
button7.hidden = NO;
cross = 1;
crosss = 1;

}else if(cross == 1){

[button5 setTitle:@"Green" forState:UIControlStateNormal];

menuRightBorder1.backgroundColor = [UIColor greenColor];
menuRightBorder.backgroundColor = [UIColor greenColor];

button7.hidden = NO;
button6.hidden = YES;
cross = 2;

}else if(crosss == 0){

[button5 setTitle:@"Green" forState:UIControlStateNormal];

menuRightBorder1.backgroundColor = [UIColor greenColor];
menuRightBorder.backgroundColor = [UIColor greenColor];

button7.hidden = NO;
button6.hidden = YES;
cross = 2;
crosss = 1;
}
}

-(void)ButtonClicked7{

if(cross == 2){

[button5 setTitle:@"Red" forState:UIControlStateNormal];

menuRightBorder1.backgroundColor = [UIColor redColor];
menuRightBorder.backgroundColor = [UIColor redColor];
button6.hidden = NO;
button7.hidden = NO;
crosss = 0;
cross = 3;

}else if(cross == 3){

[button5 setTitle:@"Black" forState:UIControlStateNormal];

menuRightBorder1.backgroundColor = [UIColor blackColor];
menuRightBorder.backgroundColor = [UIColor blackColor];

button6.hidden = NO;
button7.hidden = YES;
cross = 0;

}else if(crosss == 1){

[button5 setTitle:@"Black" forState:UIControlStateNormal];

menuRightBorder1.backgroundColor = [UIColor blackColor];
menuRightBorder.backgroundColor = [UIColor blackColor];

button6.hidden = NO;
button7.hidden = YES;
cross = 0;
crosss = 0;
}
}

void restoreLastSession() {
    UIColor *clearColor = [UIColor blackColor];
    BOOL isOn = false;

    for(id switch_ in scrollView.subviews) {
        if([switch_ isKindOfClass:[OffsetSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            std::vector<MemoryPatch> memoryPatches = [switch_ getMemoryPatches];
            for(int i = 0; i < memoryPatches.size(); i++) {
                if(isOn){
                 memoryPatches[i].Modify();
                } else {
                 memoryPatches[i].Restore();
                }
            }
            ((OffsetSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }

        if([switch_ isKindOfClass:[TextFieldSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            ((TextFieldSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }

        if([switch_ isKindOfClass:[SliderSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            ((SliderSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }
    }

    for(id switch_ in scrollView2.subviews) {
        if([switch_ isKindOfClass:[OffsetSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            std::vector<MemoryPatch> memoryPatches = [switch_ getMemoryPatches];
            for(int i = 0; i < memoryPatches.size(); i++) {
                if(isOn){
                 memoryPatches[i].Modify();
                } else {
                 memoryPatches[i].Restore();
                }
            }
            ((OffsetSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }

        if([switch_ isKindOfClass:[TextFieldSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            ((TextFieldSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }

        if([switch_ isKindOfClass:[SliderSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            ((SliderSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }
    }

    for(id switch_ in scrollView3.subviews) {
        if([switch_ isKindOfClass:[OffsetSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            std::vector<MemoryPatch> memoryPatches = [switch_ getMemoryPatches];
            for(int i = 0; i < memoryPatches.size(); i++) {
                if(isOn){
                 memoryPatches[i].Modify();
                } else {
                 memoryPatches[i].Restore();
                }
            }
            ((OffsetSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }

        if([switch_ isKindOfClass:[TextFieldSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            ((TextFieldSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }

        if([switch_ isKindOfClass:[SliderSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            ((SliderSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }
    }

    for(id switch_ in scrollView4.subviews) {
        if([switch_ isKindOfClass:[OffsetSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            std::vector<MemoryPatch> memoryPatches = [switch_ getMemoryPatches];
            for(int i = 0; i < memoryPatches.size(); i++) {
                if(isOn){
                 memoryPatches[i].Modify();
                } else {
                 memoryPatches[i].Restore();
                }
            }
            ((OffsetSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }

        if([switch_ isKindOfClass:[TextFieldSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            ((TextFieldSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }

        if([switch_ isKindOfClass:[SliderSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            ((SliderSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }
    }

for(id switch_ in scrollView5.subviews) {
        if([switch_ isKindOfClass:[OffsetSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            std::vector<MemoryPatch> memoryPatches = [switch_ getMemoryPatches];
            for(int i = 0; i < memoryPatches.size(); i++) {
                if(isOn){
                 memoryPatches[i].Modify();
                } else {
                 memoryPatches[i].Restore();
                }
            }
            ((OffsetSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }

        if([switch_ isKindOfClass:[TextFieldSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            ((TextFieldSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }

        if([switch_ isKindOfClass:[SliderSwitch class]]) {
            isOn = [defaults boolForKey:[switch_ getPreferencesKey]];
            ((SliderSwitch*)switch_).backgroundColor = isOn ? switchOnColor : clearColor;
        }
    }
}


-(void)showMenuButton {
    NSData* data = [[NSData alloc] initWithBase64EncodedString:menuButtonBase64 options:0];
    UIImage* menuButtonImage = [UIImage imageWithData:data];

    menuButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    menuButton.frame = CGRectMake((mainWindow.frame.size.width/2), (mainWindow.frame.size.height/2), 35, 35);
    menuButton.backgroundColor = [UIColor clearColor];
    [menuButton setBackgroundImage:menuButtonImage forState:UIControlStateNormal];

    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(showMenu:)];
    [menuButton addGestureRecognizer:tapGestureRecognizer];

    [menuButton addTarget:self action:@selector(buttonDragged:withEvent:)
       forControlEvents:UIControlEventTouchDragInside];
    [mainWindow addSubview:menuButton];
}

- (void)buttonDragged:(UIButton *)button withEvent:(UIEvent *)event {
    UITouch *touch = [[event touchesForView:button] anyObject];

    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;

    button.center = CGPointMake(button.center.x + delta_x, button.center.y + delta_y);
}

-(void)menuIconTapped {
    [self showPopup:self.menuTitle.text description:credits];
    self.layer.opacity = 0.0f;
}

-(void)showPopup:(NSString *)title_ description:(NSString *)description_ {
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];

    alert.shouldDismissOnTapOutside = NO;
    alert.customViewColor = UIColorFromHex(0xFF0000);
    alert.showAnimationType = SCLAlertViewShowAnimationFadeIn;

 [alert addButton: @"Repo" actionBlock: ^(void) {
      [[UIApplication sharedApplication] openURL: [NSURL URLWithString: @"https://anemoneehack.github.io/repo"]];
    }];

 [alert addButton: @"Telegram" actionBlock: ^(void) {
      [[UIApplication sharedApplication] openURL: [NSURL URLWithString: @"https://t.me/anemonehack"]];
    }];

 [alert addButton: @"Discord" actionBlock: ^(void) {
      [[UIApplication sharedApplication] openURL: [NSURL URLWithString: @"https://discord.gg/f7FCxH3e43"]];
    }];
 
    [alert addButton: @"Ok!" actionBlock: ^(void) {
        self.layer.opacity = 1.0f;
    }];

    [alert showInfo:title_ subTitle:description_ closeButtonTitle:nil duration:9999999.0f];
}

- (void)addSwitchToMenu:(id)switch_ {
    scrollViewHeight += 55;
    scrollView.contentSize = CGSizeMake(menuWidth, scrollViewHeight);
    [scrollView addSubview:switch_];
}

- (void)addSwitchToMenu2:(id)switch_ {
    scrollView2Height += 55;
    scrollView2.contentSize = CGSizeMake(menuWidth, scrollView2Height);
    [scrollView2 addSubview:switch_];
}

- (void)addSwitchToMenu3:(id)switch_ {
    scrollView3Height += 55;
    scrollView3.contentSize = CGSizeMake(menuWidth, scrollView3Height);
    [scrollView3 addSubview:switch_];
}

- (void)addSwitchToMenu4:(id)switch_ {
    scrollView4Height += 55;
    scrollView4.contentSize = CGSizeMake(menuWidth, scrollView4Height);
    [scrollView4 addSubview:switch_];
}

- (void)addSwitchToMenu5:(id)switch_ {
    scrollView5Height += 55;
    scrollView5.contentSize = CGSizeMake(menuWidth, scrollView5Height);
    [scrollView5 addSubview:switch_];
}

-(void)setFrameworkName:(const char *)name_ {
    frameworkName = name_;
}

-(const char *)getFrameworkName {
    return frameworkName;
}
@end


@implementation OffsetSwitch {
    std::vector<MemoryPatch> memoryPatches;
}

- (id)initHackNamed:(NSString *)hackName_ description:(NSString *)description_ offsets:(std::vector<uint64_t>)offsets_ bytes:(std::vector<std::string>)bytes_ {
    description = description_;
    preferencesKey = hackName_;

    if(offsets_.size() != bytes_.size()){
        [menu showPopup:@"Invalid input count" description:[NSString stringWithFormat:@"Offsets array input count (%d) is not equal to the bytes array input count (%d)", (int)offsets_.size(), (int)bytes_.size()]];
    } else {
        for(int i = 0; i < offsets_.size(); i++) {
            MemoryPatch patch = MemoryPatch::createWithHex([menu getFrameworkName], ((offsets_[i]^ _utils.cryptBases[1]) - _utils.cryptBases[0]), bytes_[i]);
            if(patch.isValid()) {
              memoryPatches.push_back(patch);
            } else {
              [menu showPopup:@"Invalid patch" description:[NSString stringWithFormat:@"Failing offset: 0x%llx, please re-check the hex you entered.", ((offsets_[i]^ _utils.cryptBases[1]) - _utils.cryptBases[0])]];
            }
        }
    }

self = [super initWithFrame:CGRectMake(10, scrollViewX + scrollViewHeight - 1, menuWidth - 20, 50)];
    self.backgroundColor = [UIColor blackColor];
    self.layer.borderWidth = 0.5f;
    self.layer.cornerRadius = 25.0;
    self.layer.borderColor = [UIColor blackColor].CGColor;

    switchLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, menuWidth - 60, 50)];
    switchLabel.text = hackName_;
    switchLabel.textColor = switchTitleColor;
    switchLabel.font = [UIFont fontWithName:switchTitleFont size:16];
    switchLabel.adjustsFontSizeToFitWidth = true;
    switchLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:switchLabel];

UISwitch *toggleSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(menuWidth - 84, 10, 0, 0)];
toggleSwitch.onTintColor = UIColorFromHex(0xFFFFFFF);
toggleSwitch.thumbTintColor = [UIColor blackColor];
toggleSwitch.layer.borderWidth = 1.5f;
toggleSwitch.layer.cornerRadius = 16.0;
toggleSwitch.layer.borderColor = UIColorFromHex(0xFFFFFF).CGColor;
[toggleSwitch setBackgroundColor:UIColorFromHex(0x000000)];
[toggleSwitch addTarget:self action:@selector(switchToggled:) forControlEvents: UIControlEventTouchUpInside];
[self addSubview:toggleSwitch];

    BOOL isOn = [defaults boolForKey:preferencesKey];
    if([[NSUserDefaults standardUserDefaults] objectForKey:preferencesKey] != nil)
    {
        [toggleSwitch setOn:isOn animated:YES];

        for(int Index = 0; Index < memoryPatches.size(); Index++)
        {
            if(isOn)
            {
                memoryPatches[Index].Modify();
            } else {
                memoryPatches[Index].Restore();
            }
        }
    }

    return self;
}
-(void)showInfo:(UIGestureRecognizer *)gestureRec {
    if(gestureRec.state == UIGestureRecognizerStateEnded) {
        [menu showPopup:[self getPreferencesKey] description:[self getDescription]];
        menu.layer.opacity = 0.0f;
    }
}

- (void) switchToggled:(id)sender_
{
    BOOL isOn = [sender_ isOn];
    for(int Index = 0; Index < memoryPatches.size(); Index++)
    {
        if(isOn)
        {
            memoryPatches[Index].Modify();
        } else {
            memoryPatches[Index].Restore();
        }
    }

    [defaults setBool:isOn forKey:preferencesKey];

        [UIView animateWithDuration:0.25 animations:^ {
if([switches isSwitchOn:@"Watermark"]){
watermark.layer.opacity = 1;
}else{
watermark.layer.opacity = 0;
}
}];
}


-(NSString *)getPreferencesKey {
    return preferencesKey;
}

-(NSString *)getDescription {
    return description;
}

- (std::vector<MemoryPatch>)getMemoryPatches {
    return memoryPatches;
}

@end

@implementation OffseetSwitch {
    std::vector<MemoryPatch> memoryPatches;
}

- (id)initHackNamed:(NSString *)hackName_ description:(NSString *)description_ offsets:(std::vector<uint64_t>)offsets_ bytes:(std::vector<std::string>)bytes_ {
    description = description_;
    preferencesKey = hackName_;

    if(offsets_.size() != bytes_.size()){
        [menu showPopup:@"Invalid input count" description:[NSString stringWithFormat:@"Offsets array input count (%d) is not equal to the bytes array input count (%d)", (int)offsets_.size(), (int)bytes_.size()]];
    } else {
        for(int i = 0; i < offsets_.size(); i++) {
            MemoryPatch patch = MemoryPatch::createWithHex([menu getFrameworkName], ((offsets_[i]^ _utils.cryptBases[1]) - _utils.cryptBases[0]), bytes_[i]);
            if(patch.isValid()) {
              memoryPatches.push_back(patch);
            } else {
              [menu showPopup:@"Invalid patch" description:[NSString stringWithFormat:@"Failing offset: 0x%llx, please re-check the hex you entered.", ((offsets_[i]^ _utils.cryptBases[1]) - _utils.cryptBases[0])]];
            }
        }
    }

self = [super initWithFrame:CGRectMake(10, scrollViewX + scrollViewHeight - 1, 180, 50)];
    self.backgroundColor = [UIColor blackColor];
    self.layer.borderWidth = 0.5f;
    self.layer.cornerRadius = 25.0;
    self.layer.borderColor = [UIColor blackColor].CGColor;

    switchLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, menuWidth - 60, 50)];
    switchLabel.text = hackName_;
    switchLabel.textColor = switchTitleColor;
    switchLabel.font = [UIFont fontWithName:switchTitleFont size:16];
    switchLabel.adjustsFontSizeToFitWidth = true;
    switchLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:switchLabel];

UISwitch *toggleSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(120, 9, 0, 0)];
toggleSwitch.onTintColor = UIColorFromHex(0xFFFFFFF);
toggleSwitch.thumbTintColor = [UIColor blackColor];
toggleSwitch.layer.borderWidth = 1.5f;
toggleSwitch.layer.cornerRadius = 16.0;
toggleSwitch.layer.borderColor = UIColorFromHex(0xFFFFFF).CGColor;
[toggleSwitch setBackgroundColor:UIColorFromHex(0x000000)];
[toggleSwitch addTarget:self action:@selector(switchToggled:) forControlEvents: UIControlEventTouchUpInside];
[self addSubview:toggleSwitch];

    BOOL isOn = [defaults boolForKey:preferencesKey];
    if([[NSUserDefaults standardUserDefaults] objectForKey:preferencesKey] != nil)
    {
        [toggleSwitch setOn:isOn animated:YES];

        for(int Index = 0; Index < memoryPatches.size(); Index++)
        {
            if(isOn)
            {
                memoryPatches[Index].Modify();
            } else {
                memoryPatches[Index].Restore();
            }
        }
    }

    return self;
}
-(void)showInfo:(UIGestureRecognizer *)gestureRec {
    if(gestureRec.state == UIGestureRecognizerStateEnded) {
        [menu showPopup:[self getPreferencesKey] description:[self getDescription]];
        menu.layer.opacity = 0.0f;
    }
}

- (void) switchToggled:(id)sender_
{
    BOOL isOn = [sender_ isOn];
    for(int Index = 0; Index < memoryPatches.size(); Index++)
    {
        if(isOn)
        {
            memoryPatches[Index].Modify();
        } else {
            memoryPatches[Index].Restore();
        }
    }

    [defaults setBool:isOn forKey:preferencesKey];

        [UIView animateWithDuration:0.25 animations:^ {
if([switches isSwitchOn:@"Watermark"]){
watermark.layer.opacity = 1;
}else{
watermark.layer.opacity = 0;
}
}];
}


-(NSString *)getPreferencesKey {
    return preferencesKey;
}

-(NSString *)getDescription {
    return description;
}

- (std::vector<MemoryPatch>)getMemoryPatches {
    return memoryPatches;
}

@end


@implementation TextFieldSwitch {
    UITextField *textfieldValue;
}

- (id)initTextfieldNamed:(NSString *)hackName_ description:(NSString *)description_ inputBorderColor:(UIColor *)inputBorderColor_ {
    preferencesKey = hackName_;
    switchValueKey = [hackName_ stringByApplyingTransform:NSStringTransformLatinToCyrillic reverse:false];
    description = description_;

   self = [super initWithFrame:CGRectMake(10, scrollViewX + scrollViewHeight - 1, menuWidth - 20, 50)];
    self.backgroundColor = [UIColor blackColor];
    self.layer.borderWidth = 0.5f;
    self.layer.cornerRadius = 25.0;
    self.layer.borderColor = [UIColor blackColor].CGColor;

    switchLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, menuWidth - 60, 50)];
    switchLabel.text = hackName_; 
    switchLabel.textColor = switchTitleColor; 
    switchLabel.font = [UIFont fontWithName:switchTitleFont size:16]; 
    switchLabel.adjustsFontSizeToFitWidth = true; 
    switchLabel.textAlignment = NSTextAlignmentLeft; 
    [self addSubview:switchLabel]; 
 
    textfieldValue = [[UITextField alloc]initWithFrame:CGRectMake(menuWidth / 3 - -20, switchLabel.self.bounds.origin.x - 36 + switchLabel.self.bounds.size.height, menuWidth / 4, 20)];
    textfieldValue.layer.borderWidth = 2.0f;
    textfieldValue.layer.borderColor = UIColorFromHex(0xFFFFFF).CGColor;
    textfieldValue.layer.cornerRadius = 8.0f;
    textfieldValue.textColor = switchTitleColor;
    textfieldValue.textAlignment = NSTextAlignmentCenter;
    textfieldValue.delegate = self;
    textfieldValue.backgroundColor = [UIColor clearColor];

    if([[NSUserDefaults standardUserDefaults] objectForKey:switchValueKey] != nil) {
        textfieldValue.text = [[NSUserDefaults standardUserDefaults] objectForKey:switchValueKey];
    }

    [self addSubview:textfieldValue];

UISwitch *toggleSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(menuWidth - 84, 10, 0, 0)];
toggleSwitch.onTintColor = UIColorFromHex(0xFFFFFF);
toggleSwitch.thumbTintColor = [UIColor blackColor];
toggleSwitch.layer.borderWidth = 1.5f;
toggleSwitch.layer.cornerRadius = 16.0;
toggleSwitch.layer.borderColor = UIColorFromHex(0xFFFFFF).CGColor;
[toggleSwitch setBackgroundColor:UIColorFromHex(0x000000)];
[toggleSwitch addTarget:self action:@selector(switchToggled:) forControlEvents: UIControlEventTouchUpInside];
[self addSubview:toggleSwitch];


    BOOL isOn = [defaults boolForKey:preferencesKey];
    if([[NSUserDefaults standardUserDefaults] objectForKey:preferencesKey] != nil)
    {
        [toggleSwitch setOn:isOn animated:YES];
    }


    return self;
}

-(BOOL)textFieldShouldReturn:(UITextField*)textfieldValue_ {
    switchValueKey = [[self getPreferencesKey] stringByApplyingTransform:NSStringTransformLatinToCyrillic reverse:false];
    [defaults setObject:textfieldValue_.text forKey:[self getSwitchValueKey]];
    [textfieldValue_ resignFirstResponder];

    return true;
}

-(void) switchToggled:(id)sender_
{
    BOOL isOn = [sender_ isOn];
    [defaults setBool:isOn forKey:preferencesKey];
}

-(NSString *)getSwitchValueKey {
    return switchValueKey;
}

@end

@implementation SliderSwitch {
    UISlider *sliderValue;
    float valueOfSlider;
}

- (id)initSliderNamed:(NSString *)hackName_ description:(NSString *)description_ minimumValue:(float)minimumValue_ maximumValue:(float)maximumValue_ sliderColor:(UIColor *)sliderColor_{
    preferencesKey = hackName_;
    switchValueKey = [hackName_ stringByApplyingTransform:NSStringTransformLatinToCyrillic reverse:false];
    description = description_;

    self = [super initWithFrame:CGRectMake(10, scrollViewX + scrollViewHeight - 1, menuWidth - 20, 50)];
    self.backgroundColor = [UIColor blackColor];
    self.layer.borderWidth = 0.5f;
    self.layer.cornerRadius = 25.0;
    self.layer.borderColor = [UIColor blackColor].CGColor;

     switchLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, menuWidth - 60, 50)];
    switchLabel.text = hackName_;
    switchLabel.textColor = switchTitleColor;
    switchLabel.font = [UIFont fontWithName:switchTitleFont size:16];
    switchLabel.adjustsFontSizeToFitWidth = true;
    switchLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:switchLabel];

switchLabel = [[UILabel alloc]initWithFrame:CGRectMake(120, 15, 30, 20)];
    switchLabel.text = [NSString stringWithFormat:@"%.1f", sliderValue.value];
    switchLabel.textColor = switchTitleColor;
    switchLabel.font = [UIFont fontWithName:switchTitleFont size:16];
    switchLabel.layer.cornerRadius = 8.0;
    switchLabel.adjustsFontSizeToFitWidth = true;
    switchLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:switchLabel];

    sliderValue = [[UISlider alloc]initWithFrame:CGRectMake(menuWidth / 3 - -50, switchLabel.self.bounds.origin.x - 6 + switchLabel.self.bounds.size.height, menuWidth / 4 + 20, 20)];
    sliderValue.thumbTintColor = [UIColor clearColor];
    sliderValue.minimumTrackTintColor = UIColorFromHex(0xFFFFFF);
    sliderValue.maximumTrackTintColor = UIColorFromHex(0x000000);
    sliderValue.minimumValue = minimumValue_;
    sliderValue.maximumValue = maximumValue_;
    sliderValue.continuous = true;
    [sliderValue addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    valueOfSlider = sliderValue.value;
    if([[NSUserDefaults standardUserDefaults] objectForKey:switchValueKey] != nil) {
        sliderValue.value = [[NSUserDefaults standardUserDefaults] floatForKey:switchValueKey];
        switchLabel.text = [NSString stringWithFormat:@"%.1f", sliderValue.value];
    }

    [self addSubview:sliderValue];

UISwitch *toggleSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(menuWidth - 84, 10, 0, 0)];
toggleSwitch.onTintColor = UIColorFromHex(0xFFFFFF);
toggleSwitch.thumbTintColor = [UIColor blackColor];
toggleSwitch.layer.borderWidth = 1.5f;
toggleSwitch.layer.cornerRadius = 16.0;
toggleSwitch.layer.borderColor = UIColorFromHex(0xFFFFFF).CGColor;
[toggleSwitch setBackgroundColor:UIColorFromHex(0x000000)];
[toggleSwitch addTarget:self action:@selector(switchToggled:) forControlEvents: UIControlEventTouchUpInside];
[self addSubview:toggleSwitch];


    BOOL isOn = [defaults boolForKey:preferencesKey];
    if([[NSUserDefaults standardUserDefaults] objectForKey:preferencesKey] != nil)
    {
        [toggleSwitch setOn:isOn animated:YES];
    }


    return self;
}

-(void)sliderValueChanged:(UISlider *)slider_ {
    switchValueKey = [[self getPreferencesKey] stringByApplyingTransform:NSStringTransformLatinToCyrillic reverse:false];
    switchLabel.text = [NSString stringWithFormat:@"%.1f", slider_.value];
    [defaults setFloat:slider_.value forKey:[self getSwitchValueKey]];
}

-(void) switchToggled:(id)sender_
{
    BOOL isOn = [sender_ isOn];
    [defaults setBool:isOn forKey:preferencesKey];
}

@end

@implementation SlideerSwitch {
    UISlider *sliderValue;
    float valueOfSlider;
}

- (id)initSlideerNamed:(NSString *)hackName_ description:(NSString *)description_ minimumValue:(float)minimumValue_ maximumValue:(float)maximumValue_ sliderColor:(UIColor *)sliderColor_{
    preferencesKey = hackName_;
    switchValueKey = [hackName_ stringByApplyingTransform:NSStringTransformLatinToCyrillic reverse:false];
    description = description_;

    self = [super initWithFrame:CGRectMake(10, scrollViewX + scrollViewHeight - 1, menuWidth - 20, 50)];
    self.backgroundColor = [UIColor blackColor];
    self.layer.borderWidth = 0.5f;
    self.layer.cornerRadius = 25.0;
    self.layer.borderColor = [UIColor blackColor].CGColor;

    switchLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 2, menuWidth - 60, 50)];
    switchLabel.text = hackName_;
    switchLabel.textColor = switchTitleColor;
    switchLabel.font = [UIFont fontWithName:switchTitleFont size:16];
    switchLabel.adjustsFontSizeToFitWidth = true;
    switchLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:switchLabel];

    sliderValue = [[UISlider alloc]initWithFrame:CGRectMake(menuWidth / 3 - -50, switchLabel.self.bounds.origin.x - 35 + switchLabel.self.bounds.size.height, menuWidth / 4 + 20, 20)];
    sliderValue.thumbTintColor = [UIColor clearColor];
    sliderValue.minimumTrackTintColor = UIColorFromHex(0xFFFFFF);
    sliderValue.maximumTrackTintColor = UIColorFromHex(0x000000);
    sliderValue.minimumValue = minimumValue_;
    sliderValue.maximumValue = maximumValue_;
    sliderValue.continuous = true;
    [sliderValue addTarget:self action:@selector(slideerValueChanged:) forControlEvents:UIControlEventValueChanged];
    valueOfSlider = sliderValue.value;
    if([[NSUserDefaults standardUserDefaults] objectForKey:switchValueKey] != nil) {
        sliderValue.value = [[NSUserDefaults standardUserDefaults] floatForKey:switchValueKey];
        switchLabel.text = [NSString stringWithFormat:@"%@ %.1f", hackName_, sliderValue.value];
    }

    [self addSubview:sliderValue];

    return self;
}

-(void)slideerValueChanged:(UISlider *)slider_ {
    switchValueKey = [[self getPreferencesKey] stringByApplyingTransform:NSStringTransformLatinToCyrillic reverse:false];
    switchLabel.text = [NSString stringWithFormat:@"%@ %.1f", [self getPreferencesKey], slider_.value];
    [defaults setFloat:slider_.value forKey:[self getSwitchValueKey]];
}

@end

@implementation Switches


-(void)addSwitch:(NSString *)hackName_ description:(NSString *)description_ {
    OffsetSwitch *offsetPatch = [[OffsetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu:offsetPatch];

}

-(void)addSwitch1:(NSString *)hackName_ description:(NSString *)description_ {
    OffsetSwitch *offsetPatch = [[OffsetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu:offsetPatch];

}

-(void)addSwitch2:(NSString *)hackName_ description:(NSString *)description_ {
    OffsetSwitch *offsetPatch = [[OffsetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu2:offsetPatch];

}

-(void)addSwitch3:(NSString *)hackName_ description:(NSString *)description_ {
    OffsetSwitch *offsetPatch = [[OffsetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu3:offsetPatch];

}

-(void)addSwitch4:(NSString *)hackName_ description:(NSString *)description_ {
    OffsetSwitch *offsetPatch = [[OffsetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu4:offsetPatch];

}

-(void)addSwitch5:(NSString *)hackName_ description:(NSString *)description_ {
    OffsetSwitch *offsetPatch = [[OffsetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu5:offsetPatch];

}
-(void)addSwitchh:(NSString *)hackName_ description:(NSString *)description_ {
    OffseetSwitch *offsetPatch = [[OffseetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu:offsetPatch];

}

-(void)addSwitchh1:(NSString *)hackName_ description:(NSString *)description_ {
    OffseetSwitch *offsetPatch = [[OffseetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu:offsetPatch];

}

-(void)addSwitchh2:(NSString *)hackName_ description:(NSString *)description_ {
    OffseetSwitch *offsetPatch = [[OffseetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu2:offsetPatch];

}

-(void)addSwitchh3:(NSString *)hackName_ description:(NSString *)description_ {
    OffseetSwitch *offsetPatch = [[OffseetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu3:offsetPatch];

}

-(void)addSwitchh4:(NSString *)hackName_ description:(NSString *)description_ {
    OffseetSwitch *offsetPatch = [[OffseetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:std::vector<uint64_t>{} bytes:std::vector<std::string>{}];
    [menu addSwitchToMenu4:offsetPatch];

}

- (void)addOffsetSwitch:(NSString *)hackName_ description:(NSString *)description_ offsets:(std::initializer_list<uint64_t>)offsets_ bytes:(std::initializer_list<std::string>)bytes_ {
    std::vector<uint64_t> offsetVector;
    std::vector<std::string> bytesVector;

    offsetVector.insert(offsetVector.begin(), offsets_.begin(), offsets_.end());
    bytesVector.insert(bytesVector.begin(), bytes_.begin(), bytes_.end());

    OffsetSwitch *offsetPatch = [[OffsetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:offsetVector bytes:bytesVector];
    [menu addSwitchToMenu:offsetPatch];
}

- (void)addOffsetSwitch2:(NSString *)hackName_ description:(NSString *)description_ offsets:(std::initializer_list<uint64_t>)offsets_ bytes:(std::initializer_list<std::string>)bytes_ {
    std::vector<uint64_t> offsetVector;
    std::vector<std::string> bytesVector;

    offsetVector.insert(offsetVector.begin(), offsets_.begin(), offsets_.end());
    bytesVector.insert(bytesVector.begin(), bytes_.begin(), bytes_.end());

    OffsetSwitch *offsetPatch = [[OffsetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:offsetVector bytes:bytesVector];
    [menu addSwitchToMenu2:offsetPatch];
}

- (void)addOffsetSwitch3:(NSString *)hackName_ description:(NSString *)description_ offsets:(std::initializer_list<uint64_t>)offsets_ bytes:(std::initializer_list<std::string>)bytes_ {
    std::vector<uint64_t> offsetVector;
    std::vector<std::string> bytesVector;

    offsetVector.insert(offsetVector.begin(), offsets_.begin(), offsets_.end());
    bytesVector.insert(bytesVector.begin(), bytes_.begin(), bytes_.end());

    OffsetSwitch *offsetPatch = [[OffsetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:offsetVector bytes:bytesVector];
    [menu addSwitchToMenu3:offsetPatch];
}

- (void)addOffsetSwitch4:(NSString *)hackName_ description:(NSString *)description_ offsets:(std::initializer_list<uint64_t>)offsets_ bytes:(std::initializer_list<std::string>)bytes_ {
    std::vector<uint64_t> offsetVector;
    std::vector<std::string> bytesVector;

    offsetVector.insert(offsetVector.begin(), offsets_.begin(), offsets_.end());
    bytesVector.insert(bytesVector.begin(), bytes_.begin(), bytes_.end());

    OffsetSwitch *offsetPatch = [[OffsetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:offsetVector bytes:bytesVector];
    [menu addSwitchToMenu4:offsetPatch];
}

- (void)addOffseetSwitch:(NSString *)hackName_ description:(NSString *)description_ offsets:(std::initializer_list<uint64_t>)offsets_ bytes:(std::initializer_list<std::string>)bytes_ {
    std::vector<uint64_t> offsetVector;
    std::vector<std::string> bytesVector;

    offsetVector.insert(offsetVector.begin(), offsets_.begin(), offsets_.end());
    bytesVector.insert(bytesVector.begin(), bytes_.begin(), bytes_.end());

    OffseetSwitch *offsetPatch = [[OffseetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:offsetVector bytes:bytesVector];
    [menu addSwitchToMenu:offsetPatch];
}

- (void)addOffseetSwitch2:(NSString *)hackName_ description:(NSString *)description_ offsets:(std::initializer_list<uint64_t>)offsets_ bytes:(std::initializer_list<std::string>)bytes_ {
    std::vector<uint64_t> offsetVector;
    std::vector<std::string> bytesVector;

    offsetVector.insert(offsetVector.begin(), offsets_.begin(), offsets_.end());
    bytesVector.insert(bytesVector.begin(), bytes_.begin(), bytes_.end());

    OffseetSwitch *offsetPatch = [[OffseetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:offsetVector bytes:bytesVector];
    [menu addSwitchToMenu2:offsetPatch];
}

- (void)addOffseetSwitch3:(NSString *)hackName_ description:(NSString *)description_ offsets:(std::initializer_list<uint64_t>)offsets_ bytes:(std::initializer_list<std::string>)bytes_ {
    std::vector<uint64_t> offsetVector;
    std::vector<std::string> bytesVector;

    offsetVector.insert(offsetVector.begin(), offsets_.begin(), offsets_.end());
    bytesVector.insert(bytesVector.begin(), bytes_.begin(), bytes_.end());

    OffseetSwitch *offsetPatch = [[OffseetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:offsetVector bytes:bytesVector];
    [menu addSwitchToMenu3:offsetPatch];
}

- (void)addOffseetSwitch4:(NSString *)hackName_ description:(NSString *)description_ offsets:(std::initializer_list<uint64_t>)offsets_ bytes:(std::initializer_list<std::string>)bytes_ {
    std::vector<uint64_t> offsetVector;
    std::vector<std::string> bytesVector;

    offsetVector.insert(offsetVector.begin(), offsets_.begin(), offsets_.end());
    bytesVector.insert(bytesVector.begin(), bytes_.begin(), bytes_.end());

    OffseetSwitch *offsetPatch = [[OffseetSwitch alloc]initHackNamed:hackName_ description:description_ offsets:offsetVector bytes:bytesVector];
    [menu addSwitchToMenu4:offsetPatch];
}

- (void)addTextfieldSwitch:(NSString *)hackName_ description:(NSString *)description_ inputBorderColor:(UIColor *)inputBorderColor_ {
    TextFieldSwitch *textfieldSwitch = [[TextFieldSwitch alloc]initTextfieldNamed:hackName_ description:description_ inputBorderColor:inputBorderColor_];
    [menu addSwitchToMenu:textfieldSwitch];
}

- (void)addTextfieldSwitch2:(NSString *)hackName_ description:(NSString *)description_ inputBorderColor:(UIColor *)inputBorderColor_ {
    TextFieldSwitch *textfieldSwitch = [[TextFieldSwitch alloc]initTextfieldNamed:hackName_ description:description_ inputBorderColor:inputBorderColor_];
    [menu addSwitchToMenu2:textfieldSwitch];
}

- (void)addTextfieldSwitch3:(NSString *)hackName_ description:(NSString *)description_ inputBorderColor:(UIColor *)inputBorderColor_ {
    TextFieldSwitch *textfieldSwitch = [[TextFieldSwitch alloc]initTextfieldNamed:hackName_ description:description_ inputBorderColor:inputBorderColor_];
    [menu addSwitchToMenu3:textfieldSwitch];
}

- (void)addTextfieldSwitch4:(NSString *)hackName_ description:(NSString *)description_ inputBorderColor:(UIColor *)inputBorderColor_ {
    TextFieldSwitch *textfieldSwitch = [[TextFieldSwitch alloc]initTextfieldNamed:hackName_ description:description_ inputBorderColor:inputBorderColor_];
    [menu addSwitchToMenu4:textfieldSwitch];
}

- (void)addSliderSwitch:(NSString *)hackName_ description:(NSString *)description_ minimumValue:(float)minimumValue_ maximumValue:(float)maximumValue_ sliderColor:(UIColor *)sliderColor_ {
    SliderSwitch *sliderSwitch = [[SliderSwitch alloc] initSliderNamed:hackName_ description:description_ minimumValue:minimumValue_ maximumValue:maximumValue_ sliderColor:sliderColor_];
    [menu addSwitchToMenu:sliderSwitch];
}

- (void)addSliderSwitch2:(NSString *)hackName_ description:(NSString *)description_ minimumValue:(float)minimumValue_ maximumValue:(float)maximumValue_ sliderColor:(UIColor *)sliderColor_ {
    SliderSwitch *sliderSwitch = [[SliderSwitch alloc] initSliderNamed:hackName_ description:description_ minimumValue:minimumValue_ maximumValue:maximumValue_ sliderColor:sliderColor_];
    [menu addSwitchToMenu2:sliderSwitch];
}

- (void)addSliderSwitch3:(NSString *)hackName_ description:(NSString *)description_ minimumValue:(float)minimumValue_ maximumValue:(float)maximumValue_ sliderColor:(UIColor *)sliderColor_ {
    SliderSwitch *sliderSwitch = [[SliderSwitch alloc] initSliderNamed:hackName_ description:description_ minimumValue:minimumValue_ maximumValue:maximumValue_ sliderColor:sliderColor_];
    [menu addSwitchToMenu3:sliderSwitch];
}

- (void)addSliderSwitch4:(NSString *)hackName_ description:(NSString *)description_ minimumValue:(float)minimumValue_ maximumValue:(float)maximumValue_ sliderColor:(UIColor *)sliderColor_ {
    SliderSwitch *sliderSwitch = [[SliderSwitch alloc] initSliderNamed:hackName_ description:description_ minimumValue:minimumValue_ maximumValue:maximumValue_ sliderColor:sliderColor_];
    [menu addSwitchToMenu4:sliderSwitch];
}

- (void)addSlideerSwitch:(NSString *)hackName_ description:(NSString *)description_ minimumValue:(float)minimumValue_ maximumValue:(float)maximumValue_ sliderColor:(UIColor *)sliderColor_ {
    SlideerSwitch *slideerSwitch = [[SlideerSwitch alloc] initSlideerNamed:hackName_ description:description_ minimumValue:minimumValue_ maximumValue:maximumValue_ sliderColor:sliderColor_];
    [menu addSwitchToMenu:slideerSwitch];
}

- (void)addSlideerSwitch2:(NSString *)hackName_ description:(NSString *)description_ minimumValue:(float)minimumValue_ maximumValue:(float)maximumValue_ sliderColor:(UIColor *)sliderColor_ {
    SlideerSwitch *slideerSwitch = [[SlideerSwitch alloc] initSlideerNamed:hackName_ description:description_ minimumValue:minimumValue_ maximumValue:maximumValue_ sliderColor:sliderColor_];
    [menu addSwitchToMenu2:slideerSwitch];
}

- (void)addSlideerSwitch3:(NSString *)hackName_ description:(NSString *)description_ minimumValue:(float)minimumValue_ maximumValue:(float)maximumValue_ sliderColor:(UIColor *)sliderColor_ {
    SlideerSwitch *slideerSwitch = [[SlideerSwitch alloc] initSlideerNamed:hackName_ description:description_ minimumValue:minimumValue_ maximumValue:maximumValue_ sliderColor:sliderColor_];
    [menu addSwitchToMenu3:slideerSwitch];
}

- (void)addSlideerSwitch4:(NSString *)hackName_ description:(NSString *)description_ minimumValue:(float)minimumValue_ maximumValue:(float)maximumValue_ sliderColor:(UIColor *)sliderColor_ {
    SlideerSwitch *slideerSwitch = [[SlideerSwitch alloc] initSlideerNamed:hackName_ description:description_ minimumValue:minimumValue_ maximumValue:maximumValue_ sliderColor:sliderColor_];
    [menu addSwitchToMenu4:slideerSwitch];
}

- (NSString *)getValueFromSwitch:(NSString *)name {

    NSString *correctKey =  [name stringByApplyingTransform:NSStringTransformLatinToCyrillic reverse:false];

    if([[NSUserDefaults standardUserDefaults] objectForKey:correctKey]) {
        return [[NSUserDefaults standardUserDefaults] objectForKey:correctKey];
    }
    else if([[NSUserDefaults standardUserDefaults] floatForKey:correctKey]) {
        NSString *sliderValue = [NSString stringWithFormat:@"%f", [[NSUserDefaults standardUserDefaults] floatForKey:correctKey]];
        return sliderValue;
    }

    return 0;
}

-(bool)isSwitchOn:(NSString *)switchName {
    return [[NSUserDefaults standardUserDefaults] boolForKey:switchName];
}

@end