static struct Utils
{
    unsigned long long cryptBases[2] = {1156074186693914069, 6087998911114218673};
} _utils;
