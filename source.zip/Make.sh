make package file
make package install